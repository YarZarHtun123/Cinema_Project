-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cinema_db
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actor`
--

DROP TABLE IF EXISTS `actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actor` (
  `actor_id` int NOT NULL AUTO_INCREMENT,
  `actor_name` varchar(45) NOT NULL,
  PRIMARY KEY (`actor_id`),
  UNIQUE KEY `actor_id_UNIQUE` (`actor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actor`
--

LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;
INSERT INTO `actor` VALUES (1,'Lu Min'),(2,'Nay Toe'),(3,'Myint Myat'),(4,'Lwin Moe'),(6,'Wai La'),(7,'Pyi Ti Oo');
/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actress`
--

DROP TABLE IF EXISTS `actress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actress` (
  `Actress_id` int NOT NULL AUTO_INCREMENT,
  `Actress_name` varchar(45) NOT NULL,
  PRIMARY KEY (`Actress_id`),
  UNIQUE KEY `Actress_id_UNIQUE` (`Actress_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actress`
--

LOCK TABLES `actress` WRITE;
/*!40000 ALTER TABLE `actress` DISABLE KEYS */;
INSERT INTO `actress` VALUES (1,'Phway Phway'),(2,'Shwe Hmone Yati'),(3,'Moe Yu San');
/*!40000 ALTER TABLE `actress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(45) NOT NULL,
  `customer_phone` varchar(45) NOT NULL,
  `customer_address` varchar(100) NOT NULL,
  `customer_email` varchar(45) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Ni Ni ','0956786544','Magway','ni@mail.ru'),(2,'Ni Ni','09234567','Magway','nini@mail.ru'),(3,'Mg Mg','0987654332','magway','mg@gmail.com'),(4,'mi','9776777777777','mm','ms'),(5,'Niki','092585213','Korea','niki@gmail.com'),(6,'Sehun','092596300','Korea','se@gmail.com'),(7,'nihon','094652654','Japan','japan@gmail.com'),(8,'Suho','09259250087','Korea','suho@gmail.com'),(9,'Kai','09258741','Korea','kai@gmail.com'),(10,'Jay','0985412633','korea','jay@gmail.com'),(11,'Than Toe Aung','09000000000','Myay Ni Gone','than@gmail.com'),(12,'wwwww','094544444','hometwon','wwwww@gmail.com'),(13,'Kyi Pyar','09250130198','North Dagon','kyipyar@gmail.com'),(14,'Than','095465465','Myay','than@gmail.com'),(15,'Ko','093526814','Magway','ko@gmail.com'),(16,'Nyi','09362514','Ygn','nyi@gmail.com'),(17,'Bo','098765443','Ygn','bo@gmail.com'),(18,'Pa Pa','092592500887','kalay','pa@gmail.com'),(19,'KayKay','098765454','ygn','Kay@gmail.com'),(20,'dd','33','dd','dd'),(21,'ff','ff','ff','ff'),(22,'r','33','rr','r'),(23,'r','23','f','rw'),(24,'xx','4','v','xx'),(25,'jjj','34','fd','d'),(26,'tt','555','gg','tt'),(27,'gg','5','gf','gg'),(28,'gg','45','gg','rg'),(29,'ggg','ggg','ggg','rgf'),(30,'gg','666','gf','kk'),(31,'Toe','123456788','goo','toe@gmail.com'),(32,'sss','88888','sssss','sss'),(33,'aa','09123456789','sule','aa@gmail.com'),(34,'ya','555555','jjdjdj','ya@gmail.com'),(35,'dfgh','gh','gh','fgh'),(36,'Ma Bay','09123455678','Hlaing','bay@gmail.com'),(37,'Jay','09259250087','mgy','jay@mail.ru'),(38,'aaa','01444152','aaa','aaa.com'),(39,'yar','091234567','Sule','yar@gmail.com'),(40,'nay','09123456789','Sule','nay@gmail.com'),(41,'aaa','09123123','Sule','aaa.com'),(42,'nini','09123456789','Sule','nini@gmail.com'),(43,'may','09123456789','London','may@gmail.com'),(44,'Ni Ni','0925986554','Magway','ni@mail.com'),(45,'Aye','09123456789','Sule','aye@gmail.com');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `director`
--

DROP TABLE IF EXISTS `director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `director` (
  `director_id` int NOT NULL AUTO_INCREMENT,
  `director_name` varchar(45) NOT NULL,
  PRIMARY KEY (`director_id`),
  UNIQUE KEY `director_id_UNIQUE` (`director_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `director`
--

LOCK TABLES `director` WRITE;
/*!40000 ALTER TABLE `director` DISABLE KEYS */;
INSERT INTO `director` VALUES (1,'Wine'),(2,'Zin Yaw Mg Mg'),(3,'Lu Min'),(4,'Steel');
/*!40000 ALTER TABLE `director` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `emp_id` int NOT NULL AUTO_INCREMENT,
  `emp_name` text,
  `emp_phone` text,
  `emp_email` text,
  `emp_address` text,
  `username` text,
  `password` text,
  `role` text,
  `active` int DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Yarzar','09257899765','jhsadhk@gmail','Mgy','yar','yar12345','STAFF',1),(14,'Admin','34234','admin@gmail.com','Ygn','admin','admin123','ADMIN',1),(15,'John','34343434','john@gmail.com','Ygn','johnjohn','john','ADMIN',0),(16,'Merry','34343434','merry@gmail.com','Ygn','Merry Christmas','1111111111','MANAGER',0),(17,'Julia','34343434','julia@gmail.com','Ygn','JuliaJulia','Julia','STAFF',0),(23,'Su Su','09259250087','su@gmail.com','Magway','sdfsfd',NULL,'ADMIN',1),(24,'Ni Ni','092592500887','abc@gmail.com','Magway','nini123','123456','ADMIN',1),(31,'Ma Ma','7777','mama@gmail.com','aaaa','mama123','1234567','ADMIN',1),(32,'Hlaing','094565678654','hlaing@mail.ru','Ygn','hlaing123','123456','STAFF',1),(33,'ng','0987654','ma@mail.com','magway',NULL,NULL,'STAFF',1),(34,'May','09123456789','may@gmail.com','Sule','may','may','STAFF',1),(35,'kyaw','09123456789','kyaw@gmail.com','Sule','kyaw','kyaw123','STAFF',1),(36,'Naing','09123456789','naing@gmail.com','Sule','naing','naing123','STAFF',1);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `movie_id` int NOT NULL AUTO_INCREMENT,
  `movie_name` varchar(45) NOT NULL,
  `director_id` int NOT NULL,
  `actor_id` int NOT NULL,
  `actress_id` int NOT NULL,
  `movie_type_id` int NOT NULL,
  `duration` int NOT NULL,
  PRIMARY KEY (`movie_id`),
  UNIQUE KEY `movie_id_UNIQUE` (`movie_id`),
  KEY `director_id_idx` (`director_id`),
  KEY `actor_id_idx` (`actor_id`),
  KEY `actress_id_idx` (`actress_id`),
  KEY `movie_type_id_idx` (`movie_type_id`),
  CONSTRAINT `actor_id` FOREIGN KEY (`actor_id`) REFERENCES `actor` (`actor_id`),
  CONSTRAINT `actress_id` FOREIGN KEY (`actress_id`) REFERENCES `actress` (`Actress_id`),
  CONSTRAINT `director_id` FOREIGN KEY (`director_id`) REFERENCES `director` (`director_id`),
  CONSTRAINT `movie_type_id` FOREIGN KEY (`movie_type_id`) REFERENCES `movie_type` (`movie_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (1,'Danger',1,2,1,3,2),(2,'Fit',2,1,2,2,2),(3,'Fight Tee',1,1,2,2,2),(4,'Love',3,3,1,3,2),(5,'Die',1,1,2,2,2),(6,'Daddy Sugar',1,1,1,4,3),(7,'Daddy',1,1,1,1,3),(8,'MOON',2,3,1,1,5),(9,'HATER',4,7,3,7,4),(10,'Kyay Ko',2,2,2,1,3);
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_type`
--

DROP TABLE IF EXISTS `movie_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie_type` (
  `movie_type_id` int NOT NULL AUTO_INCREMENT,
  `movie_type_name` varchar(45) NOT NULL,
  PRIMARY KEY (`movie_type_id`),
  UNIQUE KEY `movie_type_id_UNIQUE` (`movie_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_type`
--

LOCK TABLES `movie_type` WRITE;
/*!40000 ALTER TABLE `movie_type` DISABLE KEYS */;
INSERT INTO `movie_type` VALUES (1,'Drama'),(2,'Action'),(3,'Romantic'),(4,'Comedy'),(5,'Adventure'),(6,'Horror'),(7,'Thriller'),(8,'Fantasy'),(9,'Thriller');
/*!40000 ALTER TABLE `movie_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_voucher`
--

DROP TABLE IF EXISTS `sale_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_voucher` (
  `sale_voucher_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `total_price` double NOT NULL,
  `voucher_num` varchar(45) NOT NULL,
  `ticket_id` int NOT NULL,
  PRIMARY KEY (`sale_voucher_id`),
  UNIQUE KEY `sale_voucher_id_UNIQUE` (`sale_voucher_id`),
  KEY `customer_id_idx` (`customer_id`),
  KEY `fk_ticket_id_idx` (`ticket_id`),
  CONSTRAINT `customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `fk_ticket_id` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`ticket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_voucher`
--

LOCK TABLES `sale_voucher` WRITE;
/*!40000 ALTER TABLE `sale_voucher` DISABLE KEYS */;
INSERT INTO `sale_voucher` VALUES (44,29,3000,'INV-0029',117),(45,30,3000,'INV-0030',118),(46,31,3000,'INV-0031',119),(47,32,3000,'INV-0032',122),(48,33,3000,'INV-0033',127),(49,33,3000,'INV-0033',128),(50,33,3000,'INV-0033',129),(51,33,3000,'INV-0033',130),(52,34,3000,'INV-0034',131),(53,34,3000,'INV-0034',132),(54,34,5000,'INV-0034',133),(55,34,5000,'INV-0034',134),(56,35,3000,'INV-0035',138),(57,35,3000,'INV-0035',139),(58,35,3000,'INV-0035',140),(59,36,3000,'INV-0036',142),(60,36,3000,'INV-0036',143),(61,37,3000,'INV-0037',144),(62,37,3000,'INV-0037',145),(63,38,5000,'INV-0038',154),(64,39,3000,'INV-0039',155),(65,40,3000,'INV-0040',156),(66,41,5000,'INV-0041',157),(67,42,3000,'INV-0042',158),(68,43,3000,'INV-0043',159),(69,44,3000,'INV-0044',160),(70,44,3000,'INV-0044',161),(71,45,3000,'INV-0045',162),(72,45,3000,'INV-0045',163),(73,45,5000,'INV-0045',164);
/*!40000 ALTER TABLE `sale_voucher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `theatre_id` int NOT NULL,
  `start_date` varchar(45) NOT NULL,
  `end_date` varchar(45) NOT NULL,
  `movie_id` int NOT NULL,
  `num_of_tickets` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`schedule_id`),
  UNIQUE KEY `schedule_id_UNIQUE` (`schedule_id`),
  KEY `theatre_id2_idx` (`theatre_id`),
  KEY `movie_id_idx` (`movie_id`),
  CONSTRAINT `movie_id` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`movie_id`),
  CONSTRAINT `theatre_id2` FOREIGN KEY (`theatre_id`) REFERENCES `theatre` (`theatre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,3,'22/3/2022','4/4/2022',1,'50'),(2,3,'3/7/2022','22/7/2022',2,'50'),(3,5,'15/7/2022','5/8/2022',3,'36'),(4,4,'24/07/2022','05/08/2022',4,'108'),(5,4,'24/07/2022','04/08/2022',2,'105'),(6,3,'24/07/2022','05/08/2022',4,'108'),(7,3,'24/07/2022','03/08/2022',4,'108'),(8,3,'24/07/2022','04/08/2022',5,'12'),(9,3,'24/07/2022','04/08/2022',5,'12'),(10,3,'24/07/2022','04/08/2022',5,'13'),(11,3,'24/07/2022','31/07/2022',3,'108'),(12,3,'24/07/2022','31/07/2022',2,'108'),(13,3,'24/07/2022','31/07/2022',4,'108'),(14,3,'15/07/2022','21/07/2022',1,'108'),(15,3,'24/07/2022','29/07/2022',1,'108'),(16,3,'23/07/2022','31/07/2022',1,'108'),(17,3,'23/07/2022','31/07/2022',1,'108'),(18,3,'23/07/2022','31/07/2022',1,'50'),(19,4,'23/07/2022','31/07/2022',1,'108'),(20,3,'23/07/2022','31/07/2022',1,'108'),(21,3,'23/07/2022','31/07/2022',1,'108'),(22,3,'23/07/2022','31/07/2022',2,'108'),(23,3,'23/07/2022','31/07/2022',1,'108'),(24,3,'23/07/2022','31/07/2022',1,'108'),(25,3,'23/07/2022','29/07/2022',1,'108'),(26,3,'05/07/2022','26/07/2022',6,'108'),(27,3,'05/07/2022','26/07/2022',7,'50'),(28,3,'05/07/2022','27/07/2022',7,'50'),(29,3,'22/07/2022','05/08/2022',3,'30'),(30,3,'12/07/2022','02/08/2022',7,'99'),(31,3,'08/07/2022','29/07/2022',7,'97'),(32,3,'10/07/2022','31/07/2022',7,'123'),(33,3,'15/07/2022','05/08/2022',7,'1356'),(34,3,'16/07/2022','06/08/2022',7,'889'),(35,3,'21/07/2022','04/08/2022',1,'80'),(36,3,'22/07/2022','12/08/2022',7,'17488'),(37,3,'17/07/2022','07/08/2022',7,'125596'),(38,3,'14/07/2022','04/08/2022',7,'12448'),(39,3,'20/07/2022','10/08/2022',7,'80'),(40,3,'23/07/2022','13/08/2022',7,'7'),(41,3,'11/07/2022','01/08/2022',7,'789'),(42,3,'09/07/2022','30/07/2022',7,'1474'),(43,3,'06/07/2022','27/07/2022',7,'6'),(44,3,'04/07/2022','25/07/2022',7,'1'),(45,3,'07/07/2022','28/07/2022',7,'1'),(46,3,'03/07/2022','24/07/2022',7,'1'),(47,3,'18/07/2022','08/08/2022',7,'123'),(48,3,'23/07/2022','27/08/2022',8,'108'),(49,3,'22/07/2022','26/08/2022',8,'108'),(50,4,'23/07/2022','27/08/2022',8,'108'),(51,4,'25/07/2022','22/08/2022',9,'72'),(52,4,'23/07/2022','20/08/2022',9,'72'),(53,4,'20/07/2022','17/08/2022',9,'72'),(54,4,'23/07/2022','20/08/2022',9,'72'),(55,3,'25/07/2022','15/08/2022',10,'36');
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_detail`
--

DROP TABLE IF EXISTS `schedule_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_detail` (
  `schedule_detail_id` int NOT NULL AUTO_INCREMENT,
  `schedule_id` int NOT NULL,
  `section_id` int NOT NULL,
  `schedule_detail_date` varchar(10) NOT NULL,
  PRIMARY KEY (`schedule_detail_id`),
  UNIQUE KEY `schedule_detail_id_UNIQUE` (`schedule_detail_id`),
  KEY `schedule_id_idx` (`schedule_id`),
  KEY `section_id_idx` (`section_id`),
  CONSTRAINT `schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`),
  CONSTRAINT `section_id` FOREIGN KEY (`section_id`) REFERENCES `section` (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_detail`
--

LOCK TABLES `schedule_detail` WRITE;
/*!40000 ALTER TABLE `schedule_detail` DISABLE KEYS */;
INSERT INTO `schedule_detail` VALUES (1,1,1,'0000-00-00'),(2,1,2,'0000-00-00'),(3,5,2,'24/07/2022'),(4,6,1,'24/07/2022'),(5,10,2,'24/07/2022'),(8,10,1,'24/07/2022'),(9,11,2,'24/07/2022'),(10,12,1,'30/07/2022'),(11,13,1,'24/07/2022'),(12,16,1,'24/07/2022'),(13,17,1,'24/07/2022'),(14,16,1,'24/07/2022'),(15,20,1,'24/07/2022'),(16,21,1,'24/07/2022'),(17,22,1,'24/07/2022'),(18,23,1,'24/07/2022'),(19,26,2,'25/07/2022'),(20,30,1,'24/07/2022'),(21,31,1,'24/07/2022'),(22,32,1,'24/07/2022'),(23,33,1,'24/07/2022'),(24,34,1,'24/07/2022'),(25,19,2,'25/07/2022'),(26,36,1,'24/07/2022'),(27,37,1,'24/07/2022'),(28,38,1,'24/07/2022'),(29,39,1,'24/07/2022'),(30,40,1,'24/07/2022'),(31,41,1,'24/07/2022'),(32,42,1,'24/07/2022'),(33,43,1,'24/07/2022'),(34,44,1,'24/07/2022'),(35,45,1,'24/07/2022'),(36,46,1,'24/07/2022'),(37,47,2,'24/07/2022'),(38,48,1,'24/07/2022'),(39,49,2,'24/07/2022'),(40,50,3,'24/07/2022'),(41,51,1,'24/07/2022'),(42,52,2,'24/07/2022'),(43,53,1,'26/07/2022'),(44,54,3,'25/07/2022'),(45,55,1,'25/07/2022');
/*!40000 ALTER TABLE `schedule_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seat`
--

DROP TABLE IF EXISTS `seat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seat` (
  `seat_id` int NOT NULL AUTO_INCREMENT,
  `seat_type` varchar(45) NOT NULL,
  `price` double NOT NULL,
  `seat_name` varchar(5) NOT NULL,
  PRIMARY KEY (`seat_id`),
  UNIQUE KEY `seat_id_UNIQUE` (`seat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seat`
--

LOCK TABLES `seat` WRITE;
/*!40000 ALTER TABLE `seat` DISABLE KEYS */;
INSERT INTO `seat` VALUES (1,'Couple',5000,'E01'),(2,'Couple',5000,'E02'),(3,'Couple',5000,'E03'),(4,'Couple',5000,'E04'),(5,'VIP',4500,'C01'),(6,'VIP',4500,'C02'),(7,'VIP',4500,'C03'),(8,'VIP',4500,'C04'),(9,'VIP',4500,'C05'),(10,'VIP',4500,'C06'),(11,'VIP',4500,'C07'),(12,'VIP',4500,'C08'),(13,'Normal',3000,'A01'),(14,'Normal',3000,'A02'),(15,'Normal',3000,'A03'),(16,'Normal',3000,'A04'),(17,'Normal',3000,'A05'),(18,'Normal',3000,'A06'),(19,'Normal',3000,'A07'),(20,'Normal',3000,'A08'),(21,'Normal',3000,'B01'),(22,'Normal',3000,'B02'),(23,'Normal',3000,'B03'),(24,'Normal',3000,'B04'),(25,'Normal',3000,'B05'),(26,'Normal',3000,'B06'),(27,'Normal',3000,'B07'),(28,'Normal',3000,'B08'),(29,'VIP',4500,'D01'),(30,'VIP',4500,'D02'),(31,'VIP',4500,'D03'),(32,'VIP',4500,'D04'),(33,'VIP',4500,'D05'),(34,'VIP',4500,'D06'),(35,'VIP',4500,'D07'),(36,'VIP',4500,'D08');
/*!40000 ALTER TABLE `seat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seat_detail`
--

DROP TABLE IF EXISTS `seat_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seat_detail` (
  `seat_detail_id` int NOT NULL AUTO_INCREMENT,
  `seat_id` int NOT NULL,
  `theatre_id` int NOT NULL,
  PRIMARY KEY (`seat_detail_id`),
  KEY `fk_seat_id_idx` (`seat_id`),
  KEY `fk_theatre_id_idx` (`theatre_id`),
  CONSTRAINT `fk_seat_id` FOREIGN KEY (`seat_id`) REFERENCES `seat` (`seat_id`),
  CONSTRAINT `fk_theatres_id` FOREIGN KEY (`theatre_id`) REFERENCES `theatre` (`theatre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seat_detail`
--

LOCK TABLES `seat_detail` WRITE;
/*!40000 ALTER TABLE `seat_detail` DISABLE KEYS */;
INSERT INTO `seat_detail` VALUES (1,13,3),(2,14,3),(3,15,3),(4,16,3),(5,17,3),(6,18,3),(7,19,3),(8,20,3),(9,21,3),(10,22,3),(11,23,3),(12,24,3),(13,25,3),(14,26,3),(15,27,3),(16,28,3),(17,29,3),(18,30,3),(19,31,3),(20,32,3),(21,33,3),(22,34,3),(23,35,3),(24,36,3),(25,1,3),(26,2,3),(27,3,3),(28,4,3),(29,5,3),(30,6,3),(31,7,3),(32,8,3),(33,9,3),(34,10,3),(35,11,3),(36,12,3),(37,2,4),(38,1,4),(39,3,4),(40,4,4),(41,5,4),(42,6,4),(43,7,4),(44,8,4),(45,9,4),(46,10,4),(47,11,4),(48,12,4),(49,13,4),(50,14,4),(51,15,4),(52,16,4),(53,17,4),(54,18,4),(55,19,4),(56,20,4),(57,21,4),(58,22,4),(59,23,4),(60,24,4),(61,25,4),(62,26,4),(63,27,4),(64,28,4),(65,29,4),(66,30,4),(67,31,4),(68,32,4),(69,33,4),(70,34,4),(71,35,4),(72,36,4);
/*!40000 ALTER TABLE `seat_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section` (
  `section_id` int NOT NULL AUTO_INCREMENT,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`section_id`),
  UNIQUE KEY `section_id_UNIQUE` (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section`
--

LOCK TABLES `section` WRITE;
/*!40000 ALTER TABLE `section` DISABLE KEYS */;
INSERT INTO `section` VALUES (1,'08:00:00','10:00:00'),(2,'10:15:00','12:00:00'),(3,'01:00:00','02:30:00');
/*!40000 ALTER TABLE `section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theatre`
--

DROP TABLE IF EXISTS `theatre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theatre` (
  `theatre_id` int NOT NULL AUTO_INCREMENT,
  `theatre_name` varchar(45) NOT NULL,
  `total_seat` varchar(45) NOT NULL,
  PRIMARY KEY (`theatre_id`),
  UNIQUE KEY `theatre_id_UNIQUE` (`theatre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theatre`
--

LOCK TABLES `theatre` WRITE;
/*!40000 ALTER TABLE `theatre` DISABLE KEYS */;
INSERT INTO `theatre` VALUES (3,'TheatreOne','36'),(4,'TheatreTwo','36');
/*!40000 ALTER TABLE `theatre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `ticket_id` int NOT NULL AUTO_INCREMENT,
  `schedule_detail_id` int NOT NULL,
  `status` varchar(45) NOT NULL,
  `date` varchar(45) DEFAULT NULL,
  `seat_detail_id` int NOT NULL,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `ticket_id_UNIQUE` (`ticket_id`),
  KEY `schedule_detail_id_idx` (`schedule_detail_id`),
  KEY `fk_seat_detail_id_idx` (`seat_detail_id`),
  CONSTRAINT `fk_seat_detail_id` FOREIGN KEY (`seat_detail_id`) REFERENCES `seat_detail` (`seat_detail_id`),
  CONSTRAINT `schedule_detail_id` FOREIGN KEY (`schedule_detail_id`) REFERENCES `schedule_detail` (`schedule_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (103,8,'Sold','24/07/2022',1),(104,8,'Sold','24/07/2022',6),(105,5,'Sold','24/07/2022',1),(106,5,'Sold','24/07/2022',2),(107,8,'Sold','24/07/2022',1),(108,8,'Sold','24/07/2022',2),(109,8,'Sold','24/07/2022',1),(110,8,'Sold','24/07/2022',2),(111,8,'Sold','24/07/2022',1),(112,8,'Sold','24/07/2022',2),(113,5,'Sold','24/07/2022',1),(114,8,'Sold','24/07/2022',1),(115,4,'Sold','24/07/2022',1),(116,5,'Sold','24/07/2022',1),(117,8,'Sold','24/07/2022',1),(118,5,'Sold','24/07/2022',1),(119,5,'Sold','24/07/2022',3),(120,9,'Sold','24/07/2022',1),(121,9,'Sold','24/07/2022',2),(122,8,'Sold','24/07/2022',1),(123,11,'Sold','24/07/2022',1),(124,11,'Sold','24/07/2022',1),(125,3,'Sold','24/07/2022',49),(126,3,'Sold','24/07/2022',50),(127,3,'Sold','24/07/2022',49),(128,3,'Sold','24/07/2022',50),(129,11,'Sold','24/07/2022',1),(130,11,'Sold','24/07/2022',2),(131,38,'Sold','24/07/2022',1),(132,38,'Sold','24/07/2022',2),(133,38,'Sold','24/07/2022',26),(134,38,'Sold','24/07/2022',27),(135,39,'Sold','24/07/2022',1),(136,39,'Sold','24/07/2022',2),(137,39,'Sold','24/07/2022',3),(138,39,'Sold','24/07/2022',1),(139,39,'Sold','24/07/2022',2),(140,39,'Sold','24/07/2022',3),(141,38,'Sold','24/07/2022',1),(142,19,'Sold','25/07/2022',1),(143,19,'Sold','25/07/2022',2),(144,25,'Sold','25/07/2022',1),(145,25,'Sold','25/07/2022',2),(146,25,'Sold','25/07/2022',3),(147,25,'Sold','25/07/2022',4),(148,25,'Sold','25/07/2022',49),(149,25,'Sold','25/07/2022',50),(150,19,'Sold','25/07/2022',28),(151,19,'Sold','25/07/2022',28),(152,19,'Sold','25/07/2022',28),(153,19,'Sold','25/07/2022',27),(154,19,'Sold','25/07/2022',27),(155,25,'Sold','25/07/2022',51),(156,25,'Sold','25/07/2022',52),(157,44,'Sold','25/07/2022',40),(158,25,'Sold','25/07/2022',57),(159,44,'Sold','25/07/2022',58),(160,19,'Sold','25/07/2022',3),(161,19,'Sold','25/07/2022',4),(162,45,'Sold','25/07/2022',1),(163,45,'Sold','25/07/2022',2),(164,45,'Sold','25/07/2022',25);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-26  7:48:13
