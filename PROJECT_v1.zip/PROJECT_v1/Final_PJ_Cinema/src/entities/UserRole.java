package entities;

public enum UserRole {
	ADMIN, USER
}
